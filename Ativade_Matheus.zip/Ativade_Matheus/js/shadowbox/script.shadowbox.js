$(function () {

    Shadowbox.init();

});